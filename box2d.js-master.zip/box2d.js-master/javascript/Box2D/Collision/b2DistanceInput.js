var b2DistanceInput = function() {
this.__varz();
this.__constructor.apply(this, arguments);
}
b2DistanceInput.prototype.__constructor = function(){}
b2DistanceInput.prototype.__varz = function(){
}
// static methods
// static attributes
// methods
// attributes
b2DistanceInput.prototype.proxyA =  null;
b2DistanceInput.prototype.proxyB =  null;
b2DistanceInput.prototype.transformA =  null;
b2DistanceInput.prototype.transformB =  null;
b2DistanceInput.prototype.useRadii =  null;