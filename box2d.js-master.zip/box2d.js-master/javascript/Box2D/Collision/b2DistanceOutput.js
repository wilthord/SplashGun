var b2DistanceOutput = function() {
this.__varz();
this.__constructor.apply(this, arguments);
}
b2DistanceOutput.prototype.__constructor = function(){}
b2DistanceOutput.prototype.__varz = function(){
this.pointA =  new b2Vec2();
this.pointB =  new b2Vec2();
}
// static methods
// static attributes
// methods
// attributes
b2DistanceOutput.prototype.pointA =  new b2Vec2();
b2DistanceOutput.prototype.pointB =  new b2Vec2();
b2DistanceOutput.prototype.distance =  null;
b2DistanceOutput.prototype.iterations =  0;