var b2DynamicTreePair = function() {
this.__varz();
this.__constructor.apply(this, arguments);
}
b2DynamicTreePair.prototype.__constructor = function(){}
b2DynamicTreePair.prototype.__varz = function(){
}
// static methods
// static attributes
// methods
// attributes
b2DynamicTreePair.prototype.proxyA =  null;
b2DynamicTreePair.prototype.proxyB =  null;