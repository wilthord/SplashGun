var b2RayCastOutput = function() {
this.__varz();
this.__constructor.apply(this, arguments);
}
b2RayCastOutput.prototype.__constructor = function(){}
b2RayCastOutput.prototype.__varz = function(){
this.normal =  new b2Vec2();
}
// static methods
// static attributes
// methods
// attributes
b2RayCastOutput.prototype.normal =  new b2Vec2();
b2RayCastOutput.prototype.fraction =  null;