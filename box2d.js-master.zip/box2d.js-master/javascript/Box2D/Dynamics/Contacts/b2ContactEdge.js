var b2ContactEdge = function() {
this.__varz();
this.__constructor.apply(this, arguments);
}
b2ContactEdge.prototype.__constructor = function(){}
b2ContactEdge.prototype.__varz = function(){
}
// static methods
// static attributes
// methods
// attributes
b2ContactEdge.prototype.other =  null;
b2ContactEdge.prototype.contact =  null;
b2ContactEdge.prototype.prev =  null;
b2ContactEdge.prototype.next =  null;