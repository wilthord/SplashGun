var b2ContactRegister = function() {
this.__varz();
this.__constructor.apply(this, arguments);
}
b2ContactRegister.prototype.__constructor = function(){}
b2ContactRegister.prototype.__varz = function(){
}
// static methods
// static attributes
// methods
// attributes
b2ContactRegister.prototype.createFcn =  null;
b2ContactRegister.prototype.destroyFcn =  null;
b2ContactRegister.prototype.primary =  null;
b2ContactRegister.prototype.pool =  null;
b2ContactRegister.prototype.poolCount =  0;