var b2ControllerEdge = function() {
this.__varz();
this.__constructor.apply(this, arguments);
}
b2ControllerEdge.prototype.__constructor = function(){}
b2ControllerEdge.prototype.__varz = function(){
}
// static methods
// static attributes
// methods
// attributes
b2ControllerEdge.prototype.controller =  null;
b2ControllerEdge.prototype.body =  null;
b2ControllerEdge.prototype.prevBody =  null;
b2ControllerEdge.prototype.nextBody =  null;
b2ControllerEdge.prototype.prevController =  null;
b2ControllerEdge.prototype.nextController =  null;