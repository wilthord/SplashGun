var b2JointEdge = function() {
this.__varz();
this.__constructor.apply(this, arguments);
}
b2JointEdge.prototype.__constructor = function(){}
b2JointEdge.prototype.__varz = function(){
}
// static methods
// static attributes
// methods
// attributes
b2JointEdge.prototype.other =  null;
b2JointEdge.prototype.joint =  null;
b2JointEdge.prototype.prev =  null;
b2JointEdge.prototype.next =  null;